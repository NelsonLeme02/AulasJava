public class Cliente extends Pessoa {
    private float valorDivida;

    public Cliente() {
      
    }

    public Cliente(String nome, String fone, float valorDivida) {
        super(nome, fone);
        this.valorDivida = valorDivida;
    }

    public float getValorDivida() {
        return valorDivida;
    }

    public void setValorDivida(float valorDivida) {
        this.valorDivida = valorDivida;
    }

    public void printCliente(Pessoa pessoa) {
        super.printPessoa(pessoa);
        String retorno = ("Valor divida: "+ this.valorDivida + "\nJuros calculado: "+ this.calculaJuros(valorDivida)+"\n");
        System.out.println(retorno);
           
    }

    public float calculaJuros(float valorDivida){
            float taxa = valorDivida * 1.12f;
            return taxa;
    }
}
