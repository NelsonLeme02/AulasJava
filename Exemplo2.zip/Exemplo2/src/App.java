public class App {
    public static void main(String[] args) throws Exception {
        Pessoa Pessoa = new Pessoa("João", "11 99999-4444");
        Cliente Cliente = new Cliente("Luana", "11 98888-4444", 100.00f);
        Fornecedor Fornecedor = new Fornecedor("Tamara", "11 96677-6661", 150.00f);

        Cliente.printCliente(Pessoa);
        Fornecedor.printFornecedor(Pessoa);
    }
}
