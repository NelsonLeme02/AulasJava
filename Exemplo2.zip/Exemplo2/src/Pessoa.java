public class Pessoa {
    private String nome;
    private String fone;
    
    public Pessoa() {
    }

    public Pessoa(String Nome, String Fone) {
        this.nome = Nome;
        this.fone = Fone;
    }

    public String getNome() {
        return nome;
    }
    
    public String getFone() {
        return fone;
    }

    public void setNome(String Nome) {
        this.nome = Nome;
    }

    public void setFone(String Fone) {
        this.fone = Fone;
    }

    public void printPessoa(Pessoa pessoa) {
        String resultado = "Nome: " + pessoa.nome + "\nTelefone: " + pessoa.fone;
        System.out.println(resultado); 
        }
    
    
}
