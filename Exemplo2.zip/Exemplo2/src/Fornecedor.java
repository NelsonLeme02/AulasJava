public class Fornecedor extends Pessoa implements Seguranca{
    private float valorCompra;

    public Fornecedor(){

    }

    public Fornecedor(String nome, String fone, float valorCompra) {
        super(nome, fone);
        this.valorCompra = valorCompra;
    }

    public float getValorCompra() {
        return valorCompra;
    }

    public void setValorCompra(float valorCompra) {
        this.valorCompra = valorCompra;
    }

       
    public void printFornecedor(Pessoa pessoa) {
        super.printPessoa(pessoa);
        String retorno = ("Valor divida: "+ this.valorCompra + "\nJuros calculado: "+ this.calculaImposto(valorCompra)+"\n");
        System.out.println(retorno);
           
    }

    public float calculaImposto(float valorCompra){
        float valorFinal = valorCompra * 1.10f;
        return valorFinal;
    }

    @Override
    public boolean validar(float dados) {
        if (this.valorCompra <= 0.0f){
            return false;
            } else {

                return true;
            }      
    }
    
}
