import Components.Interface.ILivroService;
import Components.Interface.IPublicacaoService;
import Components.Interface.IRevistaService;
import Components.Service.LivroService;
import Components.Service.PublicacaoService;
import Components.Service.RevistaService;
import Models.LivroModel;
import Models.PublicacaoModel;
import Models.RevistaModel;

// Subclasses concretas
class LivroServiceImpl extends LivroService {
    @Override
    public void Imprimir(LivroModel livro) {
        System.out.println("======================================================");
        System.out.println("Livro");
        System.out.println("Título: " + livro.getTitulo());
        System.out.println("Data de Publicação: " + livro.getDataPublicacao());
        System.out.println("Editora: " + livro.getEditora());
        System.out.println("======================================================\n");
    }
}

class PublicacaoServiceImpl extends PublicacaoService {
    @Override
    public void Imprimir(PublicacaoModel publicacao) {
        System.out.println("======================================================");
        System.out.println("Publicação");
        System.out.println("Título: " + publicacao.getTitulo());
        System.out.println("Data de Publicação: " + publicacao.getDataPublicacao());
        System.out.println("======================================================\n");
    }
}

class RevistaServiceImpl extends RevistaService {
    @Override
    public void Imprimir(RevistaModel revista) {
        System.out.println("======================================================");
        System.out.println("Revista");
        System.out.println("Título: " + revista.getTitulo());
        System.out.println("Data de Publicação: " + revista.getDataPublicacao());
        System.out.println("Editora: " + revista.getEditor());
        System.out.println("Local: " + revista.getLocal());
        System.out.println("======================================================\n");
    }
}

public class StartUp {

    private final IRevistaService _revistaService;
    private final ILivroService _livroService;
    private final IPublicacaoService _publicacaoService;

    public StartUp(IRevistaService revistaService, ILivroService livroService, IPublicacaoService publicacaoService) {
        this._livroService = livroService;
        this._revistaService = revistaService;
        this._publicacaoService = publicacaoService;
    }

    public void iniciar() throws Exception {
        PublicacaoModel publicacao = new PublicacaoModel("Public", "20/05/2009");
        RevistaModel revista = new RevistaModel("Veja", "10/01/2023", "Fatima Bernardes", "São Paulo");
        LivroModel livro = new LivroModel("O Guia do Mochileiro das Galaxias", "12/10/1979", "Editora Arqueiro");

        this._livroService.Imprimir(livro);
        this._revistaService.Imprimir(revista);
        this._publicacaoService.Imprimir(publicacao);
    }

    public static void main(String[] args) throws Exception {
        IRevistaService revistaService = new RevistaServiceImpl();
        ILivroService livroService = new LivroServiceImpl();
        IPublicacaoService publicacaoService = new PublicacaoServiceImpl();

        StartUp startup = new StartUp(revistaService, livroService, publicacaoService);
        startup.iniciar();
    }
}
