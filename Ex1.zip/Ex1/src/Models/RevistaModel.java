package Models;

public class RevistaModel extends PublicacaoModel{

    private String editor;
    private String local;

    public RevistaModel(String Titulo, String DataPublicacao, String Editor, String Local) {
        super(Titulo, DataPublicacao);
        this.editor = Editor;
        this.local = Local;
    }
    
    public String getEditor(){
        return this.editor;
    }

    public String getLocal(){
        return this.local;
    }
}
