package Models;

public class PublicacaoModel  {
    
    private String titulo;
    private String dataPublicacao;

    public PublicacaoModel(String Titulo, String DataPublicacao){
        this.titulo = Titulo;
        this.dataPublicacao = DataPublicacao;
    }

    public String getTitulo() {
        return this.titulo;
    }

    public String getDataPublicacao() {
        return this.dataPublicacao;
    }
}
