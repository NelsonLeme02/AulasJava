package Models;

public class LivroModel extends PublicacaoModel{

    private String editora;

    public LivroModel(String Titulo, String DataPublicacao, String Editora) {
        super(Titulo, DataPublicacao);
        this.editora = Editora;
    }

    public String getEditora(){
        return this.editora;
    } 
    
}
