package Components.Interface;

import Models.LivroModel;

public interface ILivroService {
    
    void Imprimir(LivroModel livro);
}
