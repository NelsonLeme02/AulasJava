package Components.Interface;

import Models.PublicacaoModel;

public interface IPublicacaoService {
    
    void Imprimir(PublicacaoModel publicacao);
}
