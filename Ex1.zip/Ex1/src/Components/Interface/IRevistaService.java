package Components.Interface;

import Models.RevistaModel;

public interface IRevistaService {

    void Imprimir(RevistaModel revista);
}
