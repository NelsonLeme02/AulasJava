package Components.Service;

import Components.Interface.IRevistaService;
import Models.RevistaModel;

public abstract class RevistaService implements IRevistaService {
    public abstract void Imprimir(RevistaModel revista);
}
