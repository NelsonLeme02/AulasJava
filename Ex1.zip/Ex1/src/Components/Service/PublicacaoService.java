package Components.Service;

import Components.Interface.IPublicacaoService;
import Models.PublicacaoModel;

public abstract class PublicacaoService implements IPublicacaoService {
    public abstract void Imprimir(PublicacaoModel publicacao);
}
