package Components.Service;

import Components.Interface.ILivroService;
import Models.LivroModel;

public abstract class LivroService implements ILivroService {
    
    public abstract void Imprimir(LivroModel livro);
}
